package com.example.parcia1.service

import com.example.parcia1.Character
import com.example.parcia1.CharacterResponse

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query



interface RickAndMortyApiService {

    @GET("character")
    fun getPersonaje(@Query("name") name: String): Call<CharacterResponse>



    @GET("character/{id}")
    fun getPersonajeById(@Path("id") id: Int): Call<Character>
}
