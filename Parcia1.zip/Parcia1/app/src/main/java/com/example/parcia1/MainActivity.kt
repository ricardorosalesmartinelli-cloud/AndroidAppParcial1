package com.example.parcia1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import com.example.parcia1.databinding.ActivityMainBinding
import com.example.parcia1.service.RetrofitClient
import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val TAG = "RickAndMortyApi"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupClickListener()
    }
// This function take a valor and saved in a variable "personajeInput".When click on butonSearch call function searchPersonaje and pass a variable on it else show text "Por favor ingresa un nombre o un id"
    private fun setupClickListener() {
        binding.btnSearch.setOnClickListener {
            val personajeInput = binding.tiePersonajeInput.text.toString().trim().lowercase()
            if (personajeInput.isNotEmpty()) {
                searchPersonaje(personajeInput)
            } else {
                Toast.makeText(this, "Por favor ingresa un nombre o un id", Toast.LENGTH_LONG).show()
            }
        }
    }

    // Function to search a character by name using the API
    private fun searchPersonaje(personajeNombre: String) { RetrofitClient.apiService.getPersonaje(personajeNombre).enqueue(object : Callback<CharacterResponse> {

        // Called when the server responds
                override fun onResponse(call: Call<CharacterResponse>, response: Response<CharacterResponse>) {
                    showLoading(false)
                    if (response.isSuccessful) {
                        val body = response.body()
                        val resultados = body?.results
                        if (!resultados.isNullOrEmpty()) {
                            val personaje = resultados[0]
                            displayPersonaje(personaje)
                            logPersonajeInfo(personaje)
                        } else {
                            showError("No se encontro información del personaje")
                        }
                    } else {
                        when (response.code()) {
                            404 -> showError("Personaje no encontrado")
                            500 -> showError("Hubo un error en el servidor")
                            else -> showError("Error: ${response.code()}")
                        }
                    }
                }
        //if response failure this function  show error message
                override fun onFailure(call: Call<CharacterResponse>, t: Throwable) {
                    showLoading(false)
                    showError("Error de conexión: ${t.message}")
                }
            })
    }

    //Function to show ProgressBar and Card visibility. if app search a character The ProgessBar is show and card is gone else ProgressBar is gone.
    private fun showLoading(show: Boolean) {
        binding.ProgressBar.visibility = if (show) View.VISIBLE else View.GONE
        binding.cardPersonaje.visibility = View.GONE
        binding.btnSearch.isEnabled = !show

    }
    //Function to show errors in app
    private fun showError(message: String) {
        binding.TvError.text = message
        binding.TvError.visibility = View.VISIBLE
        binding.cardPersonaje.visibility = View.GONE
    }
//This function print information for the programer. It doesn´t view in the app
    private fun logPersonajeInfo(character: Character) {
        Log.i(TAG, "Personaje encontrado:")
        Log.i(TAG, "Nombre: ${character.name}")
        Log.i(TAG, "ID: ${character.id}")
        Log.i(TAG, "Estado: ${character.status}")
        Log.i(TAG, "Genero: ${character.gender}")
        Log.i(TAG, "Especie: ${character.species}")
        Log.i(TAG, "Typo: ${character.type}")
    }
    //This function show a card of character with it information on app
    private fun displayPersonaje(character: Character) {
        binding.apply {
            //change visibility
            cardPersonaje.visibility = View.VISIBLE
            TvError.visibility = View.GONE

            //set api data in the card. ex: name Rick
            tvPersonajeName.text = character.name
            tvPersonajeId.text = "ID: ${character.id}"
            tvPersonajeEstado.text = character.status
            tvPersonajeGenero.text = character.gender
            tvPersonajeSpecies.text = if (character.type.isNotBlank()) {
                character.type
            } else {
                character.species
            }

//show image of the character
            character.image?.let { imageUrl ->
                Picasso.get()
                    .load(imageUrl)
                    .placeholder(R.drawable.ic_launcher_foreground)
                    .error(R.drawable.ic_launcher_foreground)
                    .into(ivPersonaje)
            }
            //This function wait for btnVerMas. it send request to Main activity 2 and a pass all the "intents". So open other view with extra atributes for the character
            binding.btnVerMas.setOnClickListener {
                val intent = Intent(this@MainActivity, MainActivity2::class.java)
                intent.putExtra("name", character.name)
                intent.putExtra("status", character.status)
                intent.putExtra("species", character.species)
                intent.putExtra("gender", character.gender)
                intent.putExtra("origin", character.origin.name)
                intent.putExtra("location", character.location.name)
                intent.putExtra("image", character.image)
                startActivity(intent)
            }

        }
    }

}
