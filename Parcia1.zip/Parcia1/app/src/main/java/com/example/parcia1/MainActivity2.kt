package com.example.parcia1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.parcia1.databinding.ActivityMain2Binding
import com.squareup.picasso.Picasso

class MainActivity2 : AppCompatActivity() {

    private lateinit var binding: ActivityMain2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)
// Declare variables and receive intents with extra information.
        val characterName = intent.getStringExtra("name")
        val characterStatus = intent.getStringExtra("status")
        val characterSpecies = intent.getStringExtra("species")
        val characterGenero = intent.getStringExtra("gender")
        val characterOrigen = intent.getStringExtra("origin")
        val characterUbicacion = intent.getStringExtra("location")
        val characterImage = intent.getStringExtra("image")

        // Create a second view whit extra information
        binding.tvDetalleName.text = characterName
        binding.tvDetalleStatus.text = "Estado: $characterStatus"
        binding.tvDetalleSpecies.text = "Especie: $characterSpecies"
        binding.tvDetalleGenero.text = "Genero: $characterGenero"
        binding.tvOrigen.text = "Origen: $characterOrigen"
        binding.tvUbicacion.text = "Ubicación: $characterUbicacion"
// show Image of Character
        characterImage?.let {
            Picasso.get()
                .load(it)
                .placeholder(R.drawable.ic_launcher_foreground)
                .error(R.drawable.ic_launcher_foreground)
                .into(binding.ivDetalleCharacter)
        }
    }
}
